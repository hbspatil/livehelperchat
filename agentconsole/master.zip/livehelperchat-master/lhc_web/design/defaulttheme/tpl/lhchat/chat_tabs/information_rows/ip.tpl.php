<tr>
    <td>IP</td>
    <td><?php echo htmlspecialchars($chat->ip)?></td>
</tr>