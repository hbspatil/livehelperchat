<h4>Start chat settings</h4>

<ul>
    <li><a href="<?php echo erLhcoreClassDesign::baseurl('chat/startchatformsettings')?>"><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('system/configuration','Default settings');?></a></li>
    <li><a href="<?php echo erLhcoreClassDesign::baseurl('chatsettings/startsettingslist')?>">List of start chat settings</li>
</ul>