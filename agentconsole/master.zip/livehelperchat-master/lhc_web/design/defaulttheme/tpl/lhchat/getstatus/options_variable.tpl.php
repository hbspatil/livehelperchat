<?php
    $chatOptionsVariable = 'LHCChatOptions';
    $chatCSSPrefix = 'lhc';
    $chatCSSLayoutOptions = array(
        'container_id' => 'lhc_container'
    )
?>