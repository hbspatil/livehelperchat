<tr>
    <td>ID</td>
    <td><?php echo $chat->id;?></td>
</tr>