<tr>
    <td><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chat/adminchat','Created')?></td>
    <td><?php echo date(erLhcoreClassModule::$dateDateHourFormat,$chat->time)?></td>
</tr>