<?php
/**
 * There can be custom html/JS if chat is closed.
 */
?>