<?php
$orderInformation = array(
    array(
        'item' => 'department',
        'enabled' => true
    ),
    array(
        'item' => 'product',
        'enabled' => true
    ),
    array(
        'item' => 'uagent',
        'enabled' => true
    ),
    array(
        'item' => 'country_code',
        'enabled' => true
    ),
    array(
        'item' => 'user_tz_identifier',
        'enabled' => true
    ),
    array(
        'item' => 'city',
        'enabled' => true
    ),
    array(
        'item' => 'ip',
        'enabled' => true
    ),
    array(
        'item' => 'referrer',
        'enabled' => true
    ),
    array(
        'item' => 'session_referrer',
        'enabled' => true
    ),
    array(
        'item' => 'id',
        'enabled' => true
    ),
    array(
        'item' => 'email',
        'enabled' => true
    ),
    array(
        'item' => 'phone',
        'enabled' => true
    ),
    array(
        'item' => 'additional_data',
        'enabled' => true
    ),
    array(
        'item' => 'created',
        'enabled' => true
    ),
    array(
        'item' => 'user_left',
        'enabled' => true
    ),
    array(
        'item' => 'wait_time',
        'enabled' => true
    ),
    array(
        'item' => 'chat_duration',
        'enabled' => true
    ),
    array(
        'item' => 'chat_status',
        'enabled' => true
    ),
    array(
        'item' => 'chat_owner',
        'enabled' => true
    )
);
?>