<?php $attribute = 'banned_ip_range'; ?>
<?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>