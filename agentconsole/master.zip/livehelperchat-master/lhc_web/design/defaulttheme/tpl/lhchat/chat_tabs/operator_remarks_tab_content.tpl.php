<div role="tabpanel" class="tab-pane<?php if ($chatTabsOrderDefault == 'operator_remarks_tab') print ' active';?>" id="main-user-info-remarks-<?php echo $chat->id?>">
   <?php include(erLhcoreClassDesign::designtpl('lhchat/chat_tabs/operator_remarks.tpl.php'));?>
</div>